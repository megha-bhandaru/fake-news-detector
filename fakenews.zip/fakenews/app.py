import streamlit as st
import pickle

# Load model & vectorizer
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# App title & description
st.set_page_config(page_title="Fake News Detector", page_icon="📰", layout="centered")
st.title("📰 Fake News Detection App")
st.write("Enter a news headline or article below to check if it's **Fake** or **Real**.")

# Input box
user_input = st.text_area("Paste your news text here:")

if st.button("Check News"):
    if user_input.strip():
        # Transform input
        input_vec = vectorizer.transform([user_input])
        
        # Predict
        prediction = model.predict(input_vec)[0]
        probability = model.predict_proba(input_vec)[0]
        
        # Display result
        if prediction == 1:
            st.error(f"🚨 This news is **FAKE** ({probability[1]*100:.2f}% confidence)")
        else:
            st.success(f"✅ This news is **REAL** ({probability[0]*100:.2f}% confidence)")
    else:
        st.warning("⚠️ Please enter some text before checking.")

# Footer
st.markdown("---")
st.caption("Made with ❤️ using Streamlit & Logistic Regression")
