# preprocess.py
import nltk
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download resources (first time only)
nltk.download('stopwords')
nltk.download('punkt')

stop_words = set(stopwords.words('english'))
punctuations = set(string.punctuation)

def preprocess(text):
    """
    Lowercase, remove punctuation, remove stopwords, tokenize.
    """
    text = text.lower()
    text = ''.join([ch for ch in text if ch not in punctuations])
    tokens = word_tokenize(text)
    tokens = [w for w in tokens if w not in stop_words]
    return ' '.join(tokens)
